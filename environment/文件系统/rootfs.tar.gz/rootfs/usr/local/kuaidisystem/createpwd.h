#ifndef CREATEPWD
#define CREATEPWD

#include <QTime>

class createpassword{
public:
    createpassword();
    static QString createpwd();
};

#endif // CREATEPWD

